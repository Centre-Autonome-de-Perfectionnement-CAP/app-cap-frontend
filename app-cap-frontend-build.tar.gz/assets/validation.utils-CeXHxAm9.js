import{aI as e,aJ as r}from"./index-CvzyzBqe.js";const n=t=>t?r.test(t.trim()):!1,o=t=>{if(!t)return!1;const a=t.trim().toUpperCase();return e.test(a)};export{n as a,o as v};
