// src/contexts/AuthContext.tsx

import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { STORAGE_KEYS, FRONTEND_ROUTES, UserRole } from '@/constants';
import authService from '@/services/auth.service';

const CAP_DIRECTION_ROLES: string[] = [
  'sec-da',
  'directrice-adjointe',
  'sec-dir',
  'directeur',
]

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  role: UserRole | null;
  nom: string | null;
  prenoms: string | null;
  userId: number | null;
  login: (token: string, userNom: string, userPrenoms: string, userRole: UserRole, userId?: number) => void;
  logout: () => Promise<void>;
}

interface AuthContextProviderProps {
  children: ReactNode;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthContextProvider: React.FC<AuthContextProviderProps> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading,       setIsLoading]       = useState<boolean>(true);
  const [role,            setRole]            = useState<UserRole | null>(null);
  const [nom,             setNom]             = useState<string | null>(null);
  const [prenoms,         setPrenoms]         = useState<string | null>(null);
  const [userId,          setUserId]          = useState<number | null>(null);

  const navigate = useNavigate();

  // Restauration de session depuis localStorage
  useEffect(() => {
    const storedToken   = localStorage.getItem(STORAGE_KEYS.TOKEN);
    const storedRole    = localStorage.getItem(STORAGE_KEYS.ROLE) as UserRole | null;
    const storedNom     = localStorage.getItem(STORAGE_KEYS.NOM);
    const storedPrenoms = localStorage.getItem(STORAGE_KEYS.PRENOMS);
    const storedUserId = localStorage.getItem(STORAGE_KEYS.USER_ID);

    if (storedToken && storedRole) {
      setIsAuthenticated(true);
      setRole(storedRole);
      setNom(storedNom);
      setPrenoms(storedPrenoms);
      setUserId(storedUserId ? parseInt(storedUserId) : null);
    }
    setIsLoading(false);
  }, []);

  // Écoute de l'événement session-expired émis par l'interceptor Axios.
  // On utilise navigate() plutôt que window.location.href pour rester
  // dans le BrowserRouter et respecter le basename="/services".
  useEffect(() => {
    const handleSessionExpired = () => {
      // localStorage a déjà été vidé par l'interceptor
      setIsAuthenticated(false);
      setRole(null);
      setNom(null);
      setPrenoms(null);
      setUserId(null);
      navigate(FRONTEND_ROUTES.LOGIN, { replace: true });
    };

    window.addEventListener('session-expired', handleSessionExpired);
    return () => window.removeEventListener('session-expired', handleSessionExpired);
  }, [navigate]);

  // ── Login avec redirection selon le rôle ────────────────────────────────
  const login = (token: string, userNom: string, userPrenoms: string, userRole: UserRole, uid?: number): void => {
    localStorage.setItem(STORAGE_KEYS.TOKEN,   token);
    localStorage.setItem(STORAGE_KEYS.NOM,     userNom);
    localStorage.setItem(STORAGE_KEYS.PRENOMS, userPrenoms);
    localStorage.setItem(STORAGE_KEYS.ROLE,    userRole);
    if (uid !== undefined) {
      localStorage.setItem(STORAGE_KEYS.USER_ID, uid.toString());
      setUserId(uid);
    }

    setNom(userNom);
    setPrenoms(userPrenoms);
    setRole(userRole);
    setIsAuthenticated(true);

    // Redirection selon le rôle dès la connexion
    const r = userRole as string;
    if (CAP_DIRECTION_ROLES.includes(r)) {
      navigate(FRONTEND_ROUTES.DEMANDES_CAP);
    } else if (r === 'responsable') {
      // Responsable de division → son espace dédié
      navigate(FRONTEND_ROUTES.RESPONSABLE_DASHBOARD);
    } else if (r === 'professeur') {
      // Professeur → dashboard notes
      navigate(FRONTEND_ROUTES.NOTES.PROFESSOR_DASHBOARD);
    } else {
      // Tous les autres (admin, secrétaire, comptable...) → portail des modules
      navigate(FRONTEND_ROUTES.PORTAIL);
    }
  };

  // ── Logout ───────────────────────────────────────────────────────────────
  const logout = async (): Promise<void> => {
    const currentRole = role as string | null;

    try {
      await authService.logout();
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
    } finally {
      localStorage.removeItem(STORAGE_KEYS.TOKEN);
      localStorage.removeItem(STORAGE_KEYS.ROLE);
      localStorage.removeItem(STORAGE_KEYS.NOM);
      localStorage.removeItem(STORAGE_KEYS.PRENOMS);
      localStorage.removeItem(STORAGE_KEYS.USER_ID);

      setIsAuthenticated(false);
      setRole(null);
      setNom(null);
      setPrenoms(null);
      setUserId(null);

      if (currentRole && CAP_DIRECTION_ROLES.includes(currentRole)) {
        navigate(FRONTEND_ROUTES.DEMANDES_CAP_LOGIN);
      } else {
        navigate(FRONTEND_ROUTES.LOGIN);
      }
    }
  };

  const value: AuthContextType = {
    isAuthenticated,
    isLoading,
    role,
    nom,
    prenoms,
    userId,
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthContextProvider');
  }
  return context;
};

export { AuthContext };
